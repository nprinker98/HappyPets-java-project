import java.util.Scanner;
import java.util.ArrayList;
/**
 * 
 * @author Neal
 *
 */
public class HappyPets {
	/**
	 * declares scanner and String opt which is the option also has the switch statement which has each option
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner mkb = new Scanner(System.in);
		printMenu();
		String opt = mkb.nextLine();
		/**
		 * 
		 */
		while(opt.equals("0")==false) {
			switch(opt) {
			case("1"):
				printTotalPatientCount();
				opt = mkb.nextLine();
				break;
			case("2"):
				System.out.println("what type of pet do you have?");
				String type = mkb.nextLine();
				printPatientbyType(type);
				opt = mkb.nextLine();
				break;
			case("3"):
				System.out.println("What is the name of the pet");
				String name = mkb.nextLine();
				printSearchedPet(name);
				opt = mkb.nextLine();
				break;
			case("4"):
				System.out.println("What is the id number of the pet");
				String id = mkb.nextLine();
				printSearchedPet(id);
				opt = mkb.nextLine();
				break;
			case("0"):
				mkb.close();
				System.exit(0);
			default:
				System.err.println("not valid plz enter again");
				opt=mkb.nextLine();
				break;
 			}
			
		}
	}
	/**
	 * just prints the menu
	 */
	public static void printMenu() {
		System.out.println("********************************** \n \n Happy Pets Animal Hospital \n \n**********************************\n"
				+ "\nPlease select feom the following menu options\n"
				+ "	1.) Print total patient count \n"
				+ "	2.) Print a list of patients by type \n	"
				+ "3.) Search for pet by name \n"
				+ "	4.) Search for pet by i.d. \n"
				+ "	0.) exit \n please enter a selection");
	}
	/**
	 * prints the patient count, instantiates different objs in cat dog and bird to get the patient lists
	 */
	public static void printTotalPatientCount() {
		Dog dog = new Dog();
		dog.openFile();
		Cat cat = new Cat();
		cat.openFile();
		Bird bird = new Bird();
		bird.openFile();
		int x = dog.getDogCount();
		int y = cat.getCatCount();
		int z = bird.getBirdCount();
		int total = x+y+z;
		System.out.println("Total Patient Count: "+total+
				"\n dogs: "+x+"\n cats: "+ y + "\n birds: "+ z);
		printMenu();
	}
	/**
	 * takes the type of pet you are looking for and prints all the records for the type
	 * @param type
	 */
	public static void printPatientbyType(String type) {
		ArrayList<String> list=new ArrayList<String>();
		if(type.toLowerCase().equals("dog")) {
			Dog dog = new Dog();
			dog.openFile();
			list = dog.getDoglist();
			for(int i = 0; i<list.size();i++) {
			System.out.println(list.get(i));
			}
		}
		else if(type.toLowerCase().equals("cat")) {
			Cat cat = new Cat();
			cat.openFile();
			list=cat.getCatlist();
			for(int i = 0; i<list.size();i++) {
				System.out.println(list.get(i));
		}
	}
			else if(type.toLowerCase().equals("bird")) {
				Bird bird = new Bird();
				bird.openFile();
				list = bird.getBirdlist();
				for(int i=0;i<list.size();i++) {
					System.out.println(list.get(i));
				
			}
		}
			else {
				System.err.println("not a valid option returning to menu");
				
				
			}
		printMenu();
	}
	/**
	 * Serves as the method for opt 3 and 4 that takes the name or id and searches all pet files for the patient
	 * @param name
	 */
	public static void printSearchedPet(String name) {
		Dog dog = new Dog();
		dog.openFile();
		Cat cat = new Cat();
		cat.openFile();
		Bird bird = new Bird();
		bird.openFile();
		ArrayList<String> petList = new ArrayList<String>();
		petList = dog.getDoglist();
		if(dog.search4Pet(name, petList).equals(name)) {
			petList=cat.getCatlist();
			if(cat.search4Pet(name, petList).equals(name)) {
				petList=bird.getBirdlist();
				if(bird.search4Pet(name, petList).equals(name)) {
					System.err.println("no record found");
					System.exit(2);
			}
				else {
					name=bird.search4Pet(name, petList);
					System.out.println(name);
				}}
			else {
				name=cat.search4Pet(name, petList);
				System.out.println(name);
			}
			}
			else {
				name=dog.search4Pet(name, petList);
				System.out.println(name);
			}
		printMenu();
		}
	
	}


	
