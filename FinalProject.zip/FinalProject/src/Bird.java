import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
/**
 * bird class that inherits from pet.java
 * @author Neal
 *
 */
public class Bird extends Pet {
	private File file;
	private Scanner scan;
	private ArrayList<String> birdList;
	private int birdCount;
	/**
	 * opens scans and stores birds.txt as an arraylist
	 */
	public void openFile() {
		file = new File("birds.txt");
		this.birdCount=0;
		birdList=new ArrayList<String>();
		try{
			scan = new Scanner(file);
			while(scan.hasNextLine()==true) {
				birdList.add(scan.nextLine());
				this.birdCount++;
		}
		}
		catch(FileNotFoundException e) {
		}
	}
	/**
	 * returns number of bird patients
	 * @return
	 */
	public int getBirdCount() {
		return this.birdCount;
	}
	/**
	 * returns list of bird patients
	 * @return
	 */
	public ArrayList<String> getBirdlist(){
		return birdList;
	}
	

}
