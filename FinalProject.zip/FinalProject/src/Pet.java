import java.util.ArrayList;
/**
 * abstract pet classs that lays out the basic ideas behind a pet
 * @author Neal
 *
 */
public abstract class Pet {
	protected String id;
	protected String name;
	protected double weight;
	protected String owner;
	protected boolean gender;
	protected String species;
	/**
	 * returns id of pet
	 * @return
	 */
	public String getId() {
		return id;
	}
	/**
	 * sets the id for that object
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * gets the name of the pet obj
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * sets the name of the pet obj
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * gets the weight of the pet obj
	 * @return
	 */
	public double getWeight() {
		return weight;
	}
	/**
	 * sets the weight of the pete obj
	 * @param weight
	 */
	public void setWeight(double weight) {
		this.weight = weight;
	}
	/**
	 * gets the name of the owner of the pet obj
	 * @return
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * sets the name of owner
	 * @param owner
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * gets the gender of the pet
	 * @return
	 */
	public boolean isGender() {
		return gender;
	}
	/**
	 * sets the gender of 
	 * @param gender
	 */
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	/**
	 * gets the species of the pet obj
	 * @return
	 */
	public String getSpecies() {
		return species;
	}
	/**
	 * sets the species of the pet
	 * @param species
	 */
	public void setSpecies(String species) {
		this.species = species;
	}
	/**
	 * takes the pet type arraylist and name/id and searches through it for the intended patient
	 * @param petId
	 * @param petList
	 * @return
	 */
	public String search4Pet(String petId, ArrayList<String> petList) {
		int idSize= petId.length();
		ArrayList<String> list = new ArrayList<String>();
		list = petList;
		int index = 0;
		for(String petInfo: list) {
			
			for(int j = 0; j<list.get(index).length()-idSize;j++) {
				if(petInfo.substring(j, j+idSize).toLowerCase().equals(petId.toLowerCase())) {
					return petInfo;
				}
			}
			index++;
		}
		
		return petId;
		
	}

}
