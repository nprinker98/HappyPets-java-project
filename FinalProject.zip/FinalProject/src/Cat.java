import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
/**
 * cat class that inherits from pet.java
 * @author Neal
 *
 */
public class Cat extends Pet{
	private File file;
	private Scanner scan;
	private ArrayList<String> catList;
	private int catCount;
	/**
	 * opens,scans, and stores cats.txt into an arraylist
	 */
	public void openFile() {
		file = new File("cats.txt");
		this.catCount=0;
		catList=new ArrayList<String>();
		try{
			scan = new Scanner(file);
			while(scan.hasNextLine()==true) {
				catList.add(scan.nextLine());
				this.catCount++;
		}
		}
		catch(FileNotFoundException e) {
		}
	}
	/**
	 * returns the number of cat patients
	 * @return
	 */
	public int getCatCount() {
		return this.catCount;
	}
	/**
	 * returns list of cats
	 * @return
	 */
	public ArrayList<String> getCatlist(){
		return catList;
	}
	
	

}
