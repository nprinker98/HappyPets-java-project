import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
/**
 * dog class that inherits from pet
 * @author Neal
 *
 */
public class Dog extends Pet {
	private File file;
	private Scanner scan;
	private ArrayList<String> dogList;
	private int dogCount;
	/**
	 * opens, scans then stores dogs.txt into a arraylist
	 */
	public void openFile() {
		this.dogCount=0;
		file = new File("dogs.txt");
		try {
		scan = new Scanner(file);
		}
		catch(FileNotFoundException e){
			System.err.println(e.getMessage());
			System.exit(1);
		}
		dogList=new ArrayList<String>();
		while(scan.hasNextLine()) {
			dogList.add(scan.nextLine());
			this.dogCount++;    
			}
	}
	/**
	 * getter of the amount of dog patients
	 * @return
	 */
	public int getDogCount() {
		return this.dogCount;
	}
	/**
	 * gets the arraylist of dog patients
	 * @return
	 */
	public ArrayList<String> getDoglist(){
		return dogList;
	}
	
}
